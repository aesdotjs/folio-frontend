<template>
  <div class="w-full">
    <h1 class="px-10 pb-10 sm:pt-10 text-xl sm:text-2xl font-medium bg-superlightgrey sm:bg-transparent">Welcome on TKT dashboard !</h1>
    <BusinessTable :businesses="businesses"/>
  </div>
</template>

<script>
export default {
  name: 'IndexPage',
  async asyncData({ params, $axios, env }) {
    const businesses = await $axios.$get(`${env.APIBaseUri}/biz`);
    return { businesses };
  },
}
</script>

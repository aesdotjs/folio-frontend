<template>
  <div class="w-full">
    <header class="bg-superlightgrey px-5 pt-14 pb-20 flex items-center">
      <NavBack />
      <div class="ml-10">
        <h1 class="text-2xl">{{ business.name}}</h1>
        <h2 class="text-sm text-grey mt-2">N° SIREN {{ business.siren }}</h2>
      </div>
    </header>
    <div class="flex flex-row flex-wrap p-5 sm:p-10">
      <div class="viz-card">
        <div>
          <h1 class="text-2xl">Chiffre d'affaire</h1>
          <client-only>
            <BarChart :data="results" field="ca" class="mt-5"></BarChart>
          </client-only>
        </div>
      </div>
      <div class="viz-card">
        <div>
          <h1 class="text-2xl">EBITDA</h1>
          <client-only>
            <BarChart :data="results" field="ebitda" class="mt-5"></BarChart>
          </client-only>
        </div>
      </div>
      <div class="viz-card">
        <div>
          <h1 class="text-2xl">Loss</h1>
          <client-only>
            <BarChart :data="results" field="loss" class="mt-5"></BarChart>
          </client-only>
        </div>
      </div>
      <div class="viz-card">
        <div>
          <h1 class="text-2xl">Margin</h1>
          <client-only>
            <BarChart :data="results" field="margin" class="mt-5"></BarChart>
          </client-only>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BizId',
  async asyncData({ params, $axios, env }) {
    const business = await $axios.$get(`${env.APIBaseUri}/biz/${params.id}`);
    const results = await Promise.all(business.results.map(id => $axios.$get(`${env.APIBaseUri}/result/${id}`)));
    return { business, results };
  },
}
</script>
<style lang="postcss" scoped>
.viz-card {
  @apply w-full sm:w-1/2 flex-grow flex-shrink p-2;
  & > div {
    @apply p-5 sm:p-10 rounded-md border-lightgrey border;
  }
}
</style>

export const state = () => ({
  toggleMenu: false,
});

export const getters = {
  // Retrieve info from Store or use computed property, but a getter can be used everywhere
  toggleMenu(state) {
    return state.toggleMenu;
  },
};

export const mutations = {
  // Update nav status based on payload passed in via method function in component
  setToggleMenu(state, payload) {
    state.toggleMenu = payload;
  },
};

export const actions = {

};

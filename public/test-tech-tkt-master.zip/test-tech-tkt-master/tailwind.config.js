module.exports = {
  theme: {
    fontFamily: {
      sfpro: ["SFPRO"],
    },
    extend: {
      colors: {
        blue: {
          DEFAULT: "#4E59FF", 
        },
        red: {
          DEFAULT: "#FFEBE3",
        },
        grey: {
          DEFAULT: "#686868",
        },
        lightgrey: {
          DEFAULT: "#D6D6D6",
        },
        superlightgrey: {
          DEFAULT: "#F9F9F9",
        },
        lightblue: {
          DEFAULT: "#E8E9FA",
        },
      },
    },
  },
};

<template>
  <div class="flex flex-col sm:flex-row">
    <NavBar />
    <Nuxt />
  </div>
</template>
<script>
export default {};
</script>
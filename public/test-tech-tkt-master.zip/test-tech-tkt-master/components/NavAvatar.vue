<template>
  <div class="flex flex-row items-center px-5 py-10 mt-auto">
    <img src="~/assets/img/Avatar.png" alt="Avatar Sophie" width="50px" height="50px"/>
    <div class="ml-5">
      <h1>
        Sophie L.
      </h1>
      <p class="mt-2 text-sm">sophie.l@gmail.com</p>
    </div>
  </div>
</template>

<script>
export default {};
</script>
<template>
  <nav
    id="header"
    v-on-clickaway="away"
    class="w-full bg-superlightgrey sm:min-h-screen sm:max-w-xs p-5 relative"
    :class="{'min-h-screen' : toggleMenu }"
  >
    <div
      class="flex flex-wrap items-center w-full"
    >
      <nuxt-link
        :to="{ name: 'index' }"
        class="flex flex-row items-center px-5 py-8 cursor-pointer logo"
        @click.native="toggleMenu = false"
      >
        <img
          src="~assets/img/logo.svg"
          alt="TKT Logo"
          width="40"
          height="20"
        />
      </nuxt-link>
      <div class="ml-auto sm:hidden">
        <NavToggle />
      </div>
      <div class="w-full flex flex-col">
        <NavContent class="hidden sm:flex" />
        <CollapseTransition>
          <NavContent v-show="toggleMenu" class="sm:hidden" />
        </CollapseTransition>
      </div>
    </div>
  </nav>
</template>

<script>
import CollapseTransition from "@ivanv/vue-collapse-transition/src/CollapseTransition.vue";
import { mixin as clickaway } from "vue-clickaway";
export default {
  components: { CollapseTransition },
  mixins: [clickaway],
  computed: {
    toggleMenu: {
      get() {
        return this.$store.getters.toggleMenu;
      },
      set(value) {
        this.$store.commit("setToggleMenu", value);
      },
    },
  },
  methods: {
    away () {
      this.toggleMenu = false;
    },
  },
};
</script>

<style lang="postcss" scoped>
.logo img {
  width: 40px;
  height: 20px;
  @media (min-width: 640px) {
    width: 80px;
    height:40px;
  }
}
</style>

<template>
  <BarPlugin
    :chart-options="chartOptions"
    :chart-data="chartData"
    :chart-id="chartId"
    :dataset-id-key="datasetIdKey"
    :plugins="plugins"
    :css-classes="cssClasses"
    :styles="styles"
    :width="width"
    :height="height"
    />
</template>
<script>
export default {
  name: 'BarChart',
  props: {
    chartId: {
      type: String,
      default: 'bar-chart'
    },
    datasetIdKey: {
      type: String,
      default: 'label'
    },
    width: {
      type: Number,
      default: 400
    },
    height: {
      type: Number,
      default: 400
    },
    cssClasses: {
      default: '',
      type: String
    },
    styles: {
      type: Object,
      default: () => {}
    },
    plugins: {
      type: Object,
      default: () => {}
    },
    data: {
      type: Array,
      default: () => [],
    },
    field: {
      type: String,
      default: "",
    }
  },
  data() {
    return {
      chartData: {
        labels: this.data.map(result => result.year),
        datasets: [{ 
          data: this.data.map(result => result[this.field]),
          label: "Montant (en €)",
          backgroundColor: '#4E59FF',
        }]
      },
      chartOptions: {
        responsive: true
      }
    }
  }
}
</script>
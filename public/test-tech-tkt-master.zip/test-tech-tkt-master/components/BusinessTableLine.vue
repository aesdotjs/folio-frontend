<template>
  <div class="p-5 rounded-md border-lightgrey border">
    <nuxt-link 
      :to="{
        name: 'biz-id',
        params: { id: business.id },
      }"
      class="flex flex-row items-center">
      <div class="w-1/3 pr-2">
        {{ business.name }}
      </div>
      <div class="w-1/3 pr-2">
        {{ business.siren }}
      </div>
      <div class="w-1/3">
        <span class="px-4 py-2 rounded-md bg-blue text-white uppercase">{{ business.sector }}</span>
      </div>
    </nuxt-link>
  </div>
</template>
<script>
export default {
  props: {
    business: {
      type: Object,
      default: () => {},
    }
  }
}
</script>
<template>
  <div class="p-5">
    <div class="flex flex-row items-center text-grey text-sm uppercase py-5">
      <div class="w-1/3 pl-1">
        Company
      </div>
      <div class="w-1/3 pl-1">
        N° Siren
      </div>
      <div class="w-1/3 pl-1">
        Category
      </div>
    </div>
    <ul class="list-reset">
      <li v-for="business in businesses" :key="business.id" class="my-2">
        <BusinessTableLine :business="business" />
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  props: {
    businesses: {
      type: Array,
      default: () => [],
    }
  }
}
</script>
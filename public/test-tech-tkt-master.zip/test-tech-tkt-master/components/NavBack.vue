<template>
  <nuxt-link
    :to="{ name: 'index'}"
    aria-label="Back to home page"
    class="nav-back gradient-blue-light"
  >
    <img src="~assets/img/BackIcon.svg" alt="Back icon" width="24px" height="24px" />
  </nuxt-link>
</template>

<script>
export default {
};
</script>

<style lang="postcss" scoped>
.nav-back {
  width: 42px;
  height: 42px;
  display: block;
  border-radius: 50%;
  padding: 11px;
  box-shadow: 0px 6px 20px rgba(5, 55, 156, 0.25);
}
</style>


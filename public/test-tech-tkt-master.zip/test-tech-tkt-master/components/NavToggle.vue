<template>
  <button
    aria-label="Toggle Navigation Menu"
    class="nav-toggle gradient-blue-light"
    :class="{ active: toggleMenu }"
    @click="navToggle()"
  >
    <img src="~assets/img/BurgerIcon.svg" alt="toggle main menu icon" width="24px" height="24px" />
  </button>
</template>

<script>
export default {
  computed: {
    toggleMenu: {
      get() {
        return this.$store.getters.toggleMenu;
      },
      set(value) {
        this.$store.commit("setToggleMenu", value);
      },
    },
  },

  methods: {
    navToggle() {
      this.toggleMenu = !this.toggleMenu;
    },
  },
};
</script>

<style lang="postcss" scoped>
.nav-toggle {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  padding: 11px;
  box-shadow: 0px 6px 20px rgba(5, 55, 156, 0.25);
}
</style>

